# {{Social Listening Tool}}

## Project description

- *Welcome to our social listening tool for ExploreAI Academy! Our tool allows you to monitor and analyze social media conversations in real-time, so you can stay on top of what people are saying about our academy, courses, and programs. With our advanced analytics and customizable reports, you can gain valuable insights into customer sentiment, emerging trends, and key influencers. Whether you're a student, a teacher, or a staff member, our social listening tool can help you understand the impact of our brand and make data-driven decisions to improve our offerings.* 
- *here is the link to our notion page; https://www.notion.so/explore-ai/Social-Listening-Tool-7db315b98f8741d9ac73316f0e72fcbe*

## Team Members

- Lesego Tiro
- Bongani Mavuso
- Khamilla
- Itumeleng Kesebonye
- Ben-eze
- Maryam

## Environment

Our social listening tool is developed using Python Code and Streamlit. Python Code provides the development team with a libraries and modules for creating a robust and scalable social listening tool and Streamlit, on the other hand, is an open-source Python framework that makes it easy to build interactive data-driven applications. With its simple and intuitive API, Streamlit allows us to quickly create and deploy web-based applications that allow users to visualize and explore data in real-time. By using Streamlit in combination with python Code, we can create a social listening tool that is not only powerful and scalable, but also highly interactive and user-friendly.

### Setup - you only need to do this once

```bash
# make sure your pip in your base Python installation is up-to-date
python3 -m pip install -U pip
# install the virtualenv package
python3 -m pip install virtualenv
```

### Create the virtual environment - also typically only run when needed

```bash
# create a virtual environment in this directory called '.venv'
python3 -m venv .venv
# you should now see the folder `.venv` in your repo
```

### This is how you activate the virtual environment in a terminal and install the project dependencies

```bash
# activate the virtual environment
source .venv/bin/activate
# install the requirements for this project
pip install -r requirements.txt
```


## Tests

It's highly recommended to get in the habit of writing tests, especially once you've identified something
concrete that you can refactor into a reusable bit of code. This project has been seeded with a minimal
working example of a [refactored function](src/data/make_dataset.py),
[a notebook that can import this code](notebooks/0.0-example.ipynb) and
[a unit test to test the code behaves as expected](tests/test_make_dataset.py).

You can execute tests from the terminal by running `pytest`. IDEs like VSCode have built-in support for
executing and debugging tests through the "Testing" menu.

## Project Organisation

```ascii
├── LICENSE            <- Contains information about the legal terms and conditions under which
|                         the code can be used.
|
├── README.md          <- The top-level README for developers using this project.
│
├── docs               <- Use markdown. If/when the project becomes more complex consider migrating
|                         to something like pdoc or sphinx depending on the nature of the project.
|                         Think carefully about what documentation should sit alongside the code
|                         and what you can rather include in docstrings.
│
├── notebooks          <- Jupyter notebooks. Naming convention is a number (for ordering), and a
│                         short `-` delimited description, e.g. `1.0-initial-data-exploration`.
|                         Refactor the good parts. Don't write code to do the same task in multiple
|                         notebooks. If it's a data preprocessing task, put it in a file like
|                         `src/data/make_dataset.py`. If it's useful utility code, refactor it to
|                         `src` and import accordingly. Only commit clean notebooks (clear all cell outputs).
│
├── requirements.txt   <- The requirements file for reproducing the environment.
|
├── src                <- Source code. Refactor clean, re-usable code here.
│   │
│   ├── data           <- Separate your code base into logical groups, e.g. data, features, models, visualisation, etc.
│   │   └── make_dataset.py
│   └── ...
|
├── tests              <- Unit tests. Filename should start with "test_".
    └── test_make_dataset.py
```
