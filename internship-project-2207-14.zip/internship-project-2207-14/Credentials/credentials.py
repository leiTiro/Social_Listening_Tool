import sys
sys.path.append("..")
import gspread                      # Importing the gspread library to interact with Google Sheets
from oauth2client.service_account import ServiceAccountCredentials    # Importing the required modules for authentication

# Set up credentials to access the Google Sheet
scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']   # Setting the scope of access
creds = ServiceAccountCredentials.from_json_keyfile_name('../credentials/explore-sl-tool.json', scope)   # Loading the credentials file
client = gspread.authorize(creds)   # Authorizing the client with the given credentials